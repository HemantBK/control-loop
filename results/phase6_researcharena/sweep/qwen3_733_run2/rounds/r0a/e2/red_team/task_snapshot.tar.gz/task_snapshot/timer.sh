#!/usr/bin/env bash

NUM_HOURS=0.1667
CREATION_DATE=1792657924

DEADLINE=$((CREATION_DATE + $(python3 -c "print(int(0.1667 * 3600))")))
NOW=$(date +%s)
REMAINING=$((DEADLINE - NOW))

if [ $REMAINING -le 0 ]; then
    echo "Timer expired!"
else
    HOURS_LEFT=$((REMAINING / 3600))
    MINS_LEFT=$(((REMAINING % 3600) / 60))
    printf "Remaining time (hours:minutes): %d:%02d\n" $HOURS_LEFT $MINS_LEFT
fi
