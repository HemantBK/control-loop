/*
 * Fused SwiGLU MLP CUDA kernel — optimized implementation
 *
 * Uses cuBLAS (via torch::matmul) for the heavy GEMM work,
 * then fuses the SiLU activation + elementwise multiply in-place.
 */

#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <math.h>

// In-place fused SiLU-multiply: gate[i] = silu(gate[i]) * up[i]
// 4 elements per thread for better ILP
template <typename scalar_t>
__global__ void fused_silu_mul_inplace_kernel(
    scalar_t* __restrict__ gate,         // [N] - modified in place
    const scalar_t* __restrict__ up,     // [N]
    int N
) {
    int base_idx = (blockIdx.x * blockDim.x + threadIdx.x) * 4;
    float4* gate_vec = (float4*)gate;
    float4* up_vec = (float4*)up;
    
    if (base_idx < N/4) {
        float4 g = gate_vec[base_idx/4];
        float4 u = up_vec[base_idx/4];
        
        float4 silu_g;
        silu_g.x = g.x / (1.0f + expf(-g.x));
        silu_g.y = g.y / (1.0f + expf(-g.y));
        silu_g.z = g.z / (1.0f + expf(-g.z));
        silu_g.w = g.w / (1.0f + expf(-g.w));
        
        float4 result;
        result.x = silu_g.x * u.x;
        result.y = silu_g.y * u.y;
        result.z = silu_g.z * u.z;
        result.w = silu_g.w * u.w;
        
        ((float4*)gate)[base_idx/4] = result;
    }
    
    // Handle remainder
    #pragma unroll
    for (int i = 0; i < 4; i++) {
        int idx = base_idx + i;
        if (idx < N && idx >= N/4*4) {
            float g = static_cast<float>(gate[idx]);
            float u = static_cast<float>(up[idx]);
            float silu_g = g / (1.0f + expf(-g));
            gate[idx] = static_cast<scalar_t>(silu_g * u);
        }
    }
}

// ─── Host wrapper ────────────────────────────────────────────────────────────

torch::Tensor agent_fused_mlp(
    torch::Tensor input,        // [batch, hidden]
    torch::Tensor gate_weight,  // [intermediate, hidden]
    torch::Tensor up_weight     // [intermediate, hidden]
) {
    // Use torch matmul (cuBLAS) for the GEMMs
    auto gate_proj = torch::mm(input, gate_weight.t());
    auto up_proj = torch::mm(input, up_weight.t());

    int N = gate_proj.numel();

    int threads = 256;
    int blocks = (N + threads * 4 - 1) / (threads * 4);

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        input.scalar_type(), "fused_mlp", [&] {
            fused_silu_mul_inplace_kernel<scalar_t><<<blocks, threads>>>(
                gate_proj.data_ptr<scalar_t>(),
                up_proj.data_ptr<scalar_t>(),
                N
            );
        }
    );

    return gate_proj;  // modified in-place, no extra allocation
}
