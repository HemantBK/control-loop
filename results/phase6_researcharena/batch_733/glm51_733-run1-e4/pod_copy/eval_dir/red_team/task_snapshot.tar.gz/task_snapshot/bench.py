#!/usr/bin/env python3
"""
bench.py — Benchmark agent kernels hooked into a HuggingFace model.

Compares baseline-kernel-injected model (the initial kernels/, change 04) vs agent-kernel-injected model.
Outputs structured, greppable metrics for the harness to parse.

Usage:
    python bench.py                          # full benchmark (baseline + agent)
    python bench.py --compile-only           # just check agent compilation
    python bench.py --prompts 3              # limit number of eval prompts
"""

import os
import sys
import time
import json
import argparse
import glob
import shutil
import torch
import gc

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

from config import ArenaConfig


def apply_seed(seed: int) -> None:
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def load_model_and_tokenizer(config: ArenaConfig):
    """Load the HF model and tokenizer."""
    from transformers import AutoModelForCausalLM, AutoTokenizer

    dtype_map = {"float16": torch.float16, "bfloat16": torch.bfloat16}
    dtype = dtype_map.get(config.dtype, torch.float16)

    print(f"[bench] Loading tokenizer: {config.model_id} ...", flush=True)
    tokenizer = AutoTokenizer.from_pretrained(
        config.model_id,
        cache_dir=config.hf_cache_dir,
        trust_remote_code=True,
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    print(f"[bench] Tokenizer loaded (vocab={tokenizer.vocab_size})", flush=True)

    print(f"[bench] Loading model: {config.model_id} (dtype={config.dtype}) ...", flush=True)
    model = AutoModelForCausalLM.from_pretrained(
        config.model_id,
        torch_dtype=dtype,
        device_map=config.device,
        cache_dir=config.hf_cache_dir,
        trust_remote_code=True,
    )
    model.eval()
    print(f"[bench] Model loaded ({sum(p.numel() for p in model.parameters())/1e6:.0f}M params)", flush=True)
    return model, tokenizer


def benchmark_generation(model, tokenizer, config: ArenaConfig,
                         num_prompts: int = None) -> dict:
    """Run generation on eval prompts, measure tokens/sec."""
    prompts = config.eval_prompts[:num_prompts] if num_prompts else config.eval_prompts
    max_new = config.max_new_tokens

    # Warmup
    print(f"[bench] Warmup ({config.warmup_runs} runs) ...", flush=True)
    with torch.no_grad():
        for _ in range(config.warmup_runs):
            inputs = tokenizer("Hello", return_tensors="pt").to(config.device)
            model.generate(**inputs, max_new_tokens=8, do_sample=False, max_length=None)

    torch.cuda.synchronize()
    print(f"[bench] Warmup done", flush=True)

    total_tokens = 0
    total_time = 0.0

    print(f"[bench] Benchmarking {len(prompts)} prompts (max_new={max_new}) ...", flush=True)
    with torch.no_grad():
        for pi, prompt in enumerate(prompts):
            inputs = tokenizer(prompt, return_tensors="pt").to(config.device)
            input_len = inputs["input_ids"].shape[1]

            torch.cuda.synchronize()
            t0 = time.perf_counter()

            outputs = model.generate(
                **inputs,
                max_new_tokens=max_new,
                min_new_tokens=max_new,
                do_sample=False,
                max_length=None,
            )

            torch.cuda.synchronize()
            t1 = time.perf_counter()

            gen_tokens = outputs.shape[1] - input_len
            elapsed = t1 - t0
            total_tokens += gen_tokens
            total_time += elapsed
            tps = gen_tokens / elapsed if elapsed > 0 else 0
            print(f"[bench]   prompt {pi+1}/{len(prompts)}: {gen_tokens} tokens in {elapsed:.2f}s ({tps:.1f} tok/s)", flush=True)

    avg_tps = total_tokens / total_time if total_time > 0 else 0
    return {"total_tokens": total_tokens, "total_time_s": total_time,
            "avg_tokens_per_sec": avg_tps, "num_prompts": len(prompts)}


# Benchmark change 05 (control-loop, owner 2026-10-24): upstream 11ea904's correctness check, unchanged.
def _teacher_forced_logprobs(model, input_ids, continuation=None, num_new=0):
    """Prefill over input_ids, then decode one token at a time through the KV
    cache. Feeds `continuation` if given, else the model's own greedy tokens.
    Returns (log-probs [positions, vocab] in fp32 on CPU, continuation)."""
    import torch.nn.functional as F
    steps = len(continuation) if continuation is not None else num_new
    out = model(input_ids=input_ids, use_cache=True)
    logits = [out.logits[0].float()]
    past = out.past_key_values
    tokens = []
    for i in range(steps - 1):
        nxt = continuation[i] if continuation is not None else int(logits[-1][-1].argmax())
        tokens.append(nxt)
        out = model(input_ids=torch.tensor([[nxt]], device=input_ids.device),
                    past_key_values=past, use_cache=True)
        past = out.past_key_values
        logits.append(out.logits[0].float())
    if continuation is None:
        tokens.append(int(logits[-1][-1].argmax()))
    return F.log_softmax(torch.cat(logits), dim=-1).cpu(), tokens


def reference_outputs(model, tokenizer, config: ArenaConfig) -> list:
    """Vanilla-model log-probs and greedy continuations for the correctness check."""
    refs = []
    with torch.no_grad():
        for prompt in config.correctness_prompts:
            ids = tokenizer(prompt, return_tensors="pt")["input_ids"].to(config.device)
            logp, tokens = _teacher_forced_logprobs(model, ids, num_new=config.correctness_new_tokens)
            refs.append({"input_ids": ids.cpu(), "logprobs": logp, "continuation": tokens})
    return refs


def check_correctness(model, refs: list, config: ArenaConfig) -> dict:
    """Compare a kernel-injected model against the vanilla reference."""
    kls, agree = [], []
    with torch.no_grad():
        for ref in refs:
            logp, _ = _teacher_forced_logprobs(
                model, ref["input_ids"].to(config.device), continuation=ref["continuation"])
            if not torch.isfinite(logp).all():
                return {"correctness": "FAIL", "mean_kl": float("inf"), "top1_agree": 0.0,
                        "reason": "non-finite logits"}
            p = ref["logprobs"]
            kls.append((p.exp() * (p - logp)).sum(-1))
            agree.append((p.argmax(-1) == logp.argmax(-1)).float())
    mean_kl = torch.cat(kls).mean().item()
    top1 = torch.cat(agree).mean().item()
    ok = mean_kl <= config.correctness_max_mean_kl and top1 >= config.correctness_min_top1_agree
    return {"correctness": "PASS" if ok else "FAIL", "mean_kl": mean_kl, "top1_agree": top1}


def compile_kernels(kernels_dir, bindings_path, name, build_suffix=""):
    """Compile kernels from a given directory. Returns (module, error_string)."""
    from torch.utils.cpp_extension import load

    sources = [bindings_path]
    sources.extend(sorted(glob.glob(os.path.join(kernels_dir, "*.cu"))))
    if not sources:
        return None, "No source files found"

    build_dir = os.path.join("/tmp", f"arena_build_{os.getpid()}{build_suffix}")
    os.makedirs(build_dir, exist_ok=True)

    # Force rebuild
    if os.path.exists(build_dir):
        try:
            shutil.rmtree(build_dir)
        except OSError:
            stale = build_dir + f".stale.{os.getpid()}"
            os.rename(build_dir, stale)
        os.makedirs(build_dir, exist_ok=True)

    try:
        module = load(
            name=name,
            sources=sources,
            build_directory=build_dir,
            extra_cuda_cflags=["-O3", "--use_fast_math", "-lineinfo"],
            extra_cflags=["-O3"],
            verbose=False,
        )
        return module, None
    except Exception as e:
        return None, str(e)


def run_benchmark(config: ArenaConfig = None, compile_only: bool = False,
                  num_prompts: int = None, verbose: bool = False):
    """
    Main benchmark entry point.

    Compares baseline (initial kernels/ from baseline_kernels/ injected) vs agent (agent kernels injected),
    and checks both injected models against vanilla HF (check_correctness; change 05).
    Baseline TPS and the vanilla reference are cached in workspace/.
    """
    if config is None:
        config = ArenaConfig()
    apply_seed(config.seed)

    os.makedirs(config.workspace_dir, exist_ok=True)
    result = {"compile_status": "SKIP", "injected": {}, "speedup": 1.0}

    # ── Step 1: Compile agent kernels ─────────────────────────────────────
    agent_kernels_dir = os.path.join(ROOT, "kernels")
    agent_bindings = os.path.join(ROOT, "bindings.cpp")

    agent_ops, agent_err = compile_kernels(
        agent_kernels_dir, agent_bindings, name="agent_ops")

    if agent_err:
        result["compile_status"] = "FAIL"
        result["compile_error"] = agent_err
        print(f"COMPILE_STATUS=FAIL")
        print(f"COMPILE_ERROR={agent_err}")
        return result

    result["compile_status"] = "PASS"
    funcs = [f for f in dir(agent_ops) if not f.startswith("_")]
    print(f"COMPILE_STATUS=PASS")
    print(f"COMPILE_FUNCTIONS={','.join(funcs)}")

    if compile_only:
        return result

    # ── Step 2: Vanilla reference for the correctness check (cached) ──────
    # Change 05 (11ea904): computed before any injection, so apply_rotary_pos_emb is unpatched.
    reference_cache = os.path.join(config.workspace_dir, "reference_outputs.pt")
    if os.path.exists(reference_cache):
        refs = torch.load(reference_cache)
    else:
        print("Computing vanilla reference outputs for correctness check...")
        model, tokenizer = load_model_and_tokenizer(config)
        refs = reference_outputs(model, tokenizer, config)
        torch.save(refs, reference_cache)
        del model
        gc.collect()
        torch.cuda.empty_cache()

    # ── Step 3: Get baseline TPS (cached or compute) ──────────────────────
    baseline_cache = os.path.join(config.workspace_dir, "baseline_tps.txt")

    if os.path.exists(baseline_cache):
        baseline_tps = float(open(baseline_cache).read().strip())
        print(f"BASELINE_TPS={baseline_tps:.2f} (cached)")
    else:
        # Compile starter kernels as baseline
        # Benchmark change 04 (control-loop, owner 2026-10-23): the baseline is the agent's initial kernels/, kept as a
        # byte-identical snapshot in task_context/baseline_kernels/ (with bindings.cpp), so leaving the kernels
        # unchanged scores about 1.0x. Before: task_context/starter_kernels (change 02), slower naive kernels that
        # the unmodified kernels/ already beat by about 2.2x on an H100 (fullrun2, 2026-10-23).
        starter_dir = os.path.join(ROOT, "baseline_kernels")
        starter_bindings = os.path.join(starter_dir, "bindings.cpp")

        if not os.path.isdir(starter_dir):
            # Fallback: use agent kernels as baseline (starters not available)
            print(f"WARNING: starter_kernels not found at {starter_dir}")
            print(f"Using vanilla PyTorch as baseline (no kernel injection)")
            model, tokenizer = load_model_and_tokenizer(config)
            baseline_results = benchmark_generation(model, tokenizer, config, num_prompts)
            baseline_tps = baseline_results["avg_tokens_per_sec"]
            del model
            gc.collect()
            torch.cuda.empty_cache()
        else:
            print(f"Compiling baseline from {starter_dir}...")
            baseline_ops, bl_err = compile_kernels(
                starter_dir, starter_bindings, name="baseline_ops", build_suffix="_baseline")

            if bl_err:
                print(f"WARNING: Baseline compile failed: {bl_err}")
                print(f"Using vanilla PyTorch as baseline")
                model, tokenizer = load_model_and_tokenizer(config)
                baseline_results = benchmark_generation(model, tokenizer, config, num_prompts)
                baseline_tps = baseline_results["avg_tokens_per_sec"]
                del model
                gc.collect()
                torch.cuda.empty_cache()
            else:
                # Load model, inject baseline kernels, benchmark, then clean up
                print("Running baseline benchmark (baseline kernels: the initial kernels/, injected)...")
                from inject import inject_agent_kernels
                model, tokenizer = load_model_and_tokenizer(config)
                inject_agent_kernels(model, baseline_ops, verbose=verbose)
                bl_correct = check_correctness(model, refs, config)   # change 05: reported, not gated
                result["baseline_correctness"] = bl_correct["correctness"]
                result["baseline_mean_kl"] = bl_correct["mean_kl"]
                result["baseline_top1_agree"] = bl_correct["top1_agree"]
                print(f"BASELINE_CORRECTNESS={bl_correct['correctness']} "
                      f"(mean_kl={bl_correct['mean_kl']:.2e}, top1_agree={bl_correct['top1_agree']:.3f})")
                import inject as _inj   # change 07: per-kernel counts over the timed baseline benchmark
                _inj.reset_kernel_counts()
                baseline_results = benchmark_generation(model, tokenizer, config, num_prompts)
                result["baseline_kernel_counts"] = json.loads(json.dumps(_inj.KERNEL_COUNTS))
                print(f"BASELINE_KERNEL_COUNTS={json.dumps(_inj.KERNEL_COUNTS, sort_keys=True)}")
                baseline_tps = baseline_results["avg_tokens_per_sec"]
                # Clean up baseline model completely before loading agent model
                del model, baseline_ops
                gc.collect()
                torch.cuda.empty_cache()

        result["baseline_tps"] = baseline_tps
        print(f"BASELINE_TPS={baseline_tps:.2f}")
        with open(baseline_cache, "w") as f:
            f.write(f"{baseline_tps:.4f}\n")
        print(f"Baseline TPS cached to {baseline_cache}")

    result["baseline_tps"] = baseline_tps

    # ── Step 4: Load fresh model, inject agent kernels, check, benchmark ──
    from inject import inject_agent_kernels
    print("Loading model for agent benchmark...")
    model, tokenizer = load_model_and_tokenizer(config)
    injected = inject_agent_kernels(model, agent_ops, verbose=verbose)
    result["injected"] = injected

    any_injected = any(injected.values())
    if not any_injected:
        print("INJECT_STATUS=NONE (no kernels injected)")
        result["agent_tps"] = baseline_tps
        result["speedup"] = 1.0
        result["correctness"] = "PASS"  # nothing injected: vanilla model (change 05)
        del model
        gc.collect()
        return result

    correct = check_correctness(model, refs, config)   # change 05
    result.update(correct)
    print(f"CORRECTNESS={correct['correctness']} "
          f"(mean_kl={correct['mean_kl']:.2e}, top1_agree={correct['top1_agree']:.3f})")

    print("Running agent benchmark...")
    import inject as _inj   # change 07: per-kernel counts over the timed agent benchmark
    _inj.reset_kernel_counts()
    agent_results = benchmark_generation(model, tokenizer, config, num_prompts)
    result["kernel_counts"] = json.loads(json.dumps(_inj.KERNEL_COUNTS))
    result["kernel_first_fallback"] = dict(_inj.FIRST_FALLBACK)
    print(f"KERNEL_COUNTS={json.dumps(_inj.KERNEL_COUNTS, sort_keys=True)}")
    n_fb = sum(v.get("fallback", 0) for v in _inj.KERNEL_COUNTS.values())
    print(f"KERNEL_FALLBACKS={n_fb}" + (f" first={json.dumps(_inj.FIRST_FALLBACK)}" if n_fb else ""))
    result["agent_tps"] = agent_results["avg_tokens_per_sec"]

    speedup = agent_results["avg_tokens_per_sec"] / max(baseline_tps, 1e-6)
    result["speedup"] = speedup

    del model
    gc.collect()
    try:
        torch.cuda.empty_cache()
    except RuntimeError:
        pass

    # ── Summary ───────────────────────────────────────────────────────────
    print(f"\n{'='*60}")
    print(f" SUMMARY")
    print(f"{'='*60}")
    print(f"  COMPILE_STATUS     = {result['compile_status']}")
    print(f"  COMPILE_FUNCTIONS  = {','.join(funcs)}")
    print(f"  BASELINE_TPS       = {baseline_tps:.2f}")
    print(f"  AGENT_TPS          = {result['agent_tps']:.2f}")
    print(f"  SPEEDUP            = {speedup:.3f}x")
    print(f"  CORRECTNESS        = {result['correctness']} "
          f"(mean_kl={result['mean_kl']:.2e}, top1_agree={result['top1_agree']:.3f})")
    for k, v in injected.items():
        print(f"  KERNEL_{k.upper():20s} = {'ACTIVE' if v else 'SKIP'}")
    print(f"{'='*60}\n")

    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Benchmark agent CUDA kernels")
    parser.add_argument("--compile-only", action="store_true")
    parser.add_argument("--prompts", type=int, default=None, help="Number of prompts to test")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    result = run_benchmark(
        compile_only=args.compile_only,
        num_prompts=args.prompts,
        verbose=args.verbose,
    )

    # Save to workspace
    os.makedirs(os.path.join(ROOT, "workspace"), exist_ok=True)
    with open(os.path.join(ROOT, "workspace", "last_bench.json"), "w") as f:
        serializable = {k: v for k, v in result.items()
                        if isinstance(v, (str, int, float, bool, dict, list, type(None)))}
        json.dump(serializable, f, indent=2)
